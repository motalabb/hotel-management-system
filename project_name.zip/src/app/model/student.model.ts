
export class Student{
    id;
    name;
    mobile;
    address;
    
    constructor(id, name, mobile, address){
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.address = address;
    }

}